#include "bookSave.h"

std::vector<std::string> ParseCommand(const std::string& command) {
    std::stringstream stream(command);
    std::vector<std::string> commands;
    std::string buff;
    while(getline(stream, buff, ' ')) {
        if (buff.size() != 0) {
            commands.push_back(buff);
        }
    }
    return commands;
}
