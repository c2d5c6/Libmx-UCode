#include "src/simpleSort.h"

int main(int ac, char *av[]) {
    if (ac == 6) {
        simpleSort(av);
    }
    else{
        std::cerr << "usage: .simpleSort arg1 arg2 arg3 arg 4 arg5\n";
    }
    return (0);
}
