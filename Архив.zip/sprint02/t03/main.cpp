#include "tesLibrary.h"

int main(int argc, char** argv) {
    std::multimap<std::string, std::string> library;
    if (argc == 2) {
        std::ifstream fin(argv[1]);
        if (fin.is_open()) {
            if (CheckLineAndAdd(library, fin)) {
                return 1;
            }
            for (auto iter = library.begin(); iter != library.end(); iter = library.upper_bound(iter->first) ) {
                PrintLibrary(library, iter->first);
            }
        }
        else {
            std::cerr << "error" << std::endl;
        }
    }
    else {
        std::cerr << "usage: ./tesLibrary [file_name]" << std::endl;
    }
    return 0;
}
