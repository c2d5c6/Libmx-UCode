#pragma once

#include <iostream>
#include <string>
#include <vector>
#include <set>
#include <fstream>
#include <ostream>
#include <sstream>

struct Words {
    std::set<std::string> uniqueWords;
    std::multiset<std::string> countUniqueWords;
};

void OutInfo(Words& words, char* argv);
void ReadFile (Words& words, std::ifstream& fin);
void ReadLineAndAdd(Words& words, std::string& data);
void DeletePunctuationMarks(std::string& line);
std::string CreateNewNameFile(char *old_name);
