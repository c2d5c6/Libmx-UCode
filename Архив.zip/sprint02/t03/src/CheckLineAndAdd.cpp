#include "tesLibrary.h"

bool CheckLineAndAdd(std::multimap<std::string, std::string>& library, std::ifstream& stream) {
    std::string line;
    int count_line = 0;
    while(getline(stream, line)) {
        count_line++;
        if (line.empty()) {
            continue;
        }
        std::smatch result;
        if (std::regex_match(line, result, std::regex(R"lit(\s*"([^"]+)"\s*:\s*"([^"]+)"\s*)lit"))) {
            library.insert(std::make_pair(result.str(1), result.str(2)));
        }
        else {
            std::cerr << "Line " << count_line << " is invalid" << std::endl;
            return true;
        }
    }
    return false;
}
