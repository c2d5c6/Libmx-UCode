#include "bookSave.h"

void DeleteBook(std::map<std::string, std::string>& books, std::string book) {
    if (books.count(book) == 1) {
        books.erase(book);
        std::cout << book << " deleted\n";
    }
    else {
        InvalidArgument("invalid book");
    }
}
