#include "bookSave.h"

void ReadBook(std::map<std::string, std::string>& books, std::string book) {
    if (books.count(book) == 1) {
        std::cout << books[book] << std::endl;
    }
    else {
        InvalidArgument("invalid book");
    }
}
