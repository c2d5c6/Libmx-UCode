#include "bookSave.h"

int main() {
    std::map<std::string, std::string> book;
    try {
        while(true) {
            std::cout << "entry command:> ";
            std::string command;
            std::vector<std::string> commands;
            getline(std::cin, command);
            commands = ParseCommand(command);
            ExecutionCommand(book, commands);
        }
    }
    catch (...) {
        return 1;
    }
    return 0;
}
