#include "bookSave.h"

bool CheckSizeCommand(std::vector<std::string>& commands, size_t size) {
    if (commands.size() == size) {
        return 1;
    }
    else {
        return 0;
    }
}
