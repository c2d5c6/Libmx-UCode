#pragma once

#include <iostream>
#include <string>
#include <vector>
#include <set>
#include <map>
#include <fstream>
#include <ostream>
#include <sstream>


std::vector<std::string> ParseCommand(const std::string& command);
void InvalidArgument(std::string error);
void AddBook(std::map<std::string, std::string>& books, std::string& book);
void ReadBook(std::map<std::string, std::string>& books, std::string book);
void ListBook(std::map<std::string, std::string>& book);
void DeleteBook(std::map<std::string, std::string>& books, std::string book);
void ExecutionCommand(std::map<std::string, std::string>& book, std::vector<std::string>& commands);
bool CheckSizeCommand(std::vector<std::string>& commands, size_t size);
