#include "moveAlong.h"

size_t IteratorSearch(std::string data, std::string toSearch) {
    std::transform(data.begin(), data.end(), data.begin(), ::tolower);
    return data.find(toSearch);
}
