#pragma once

#include <array>
#include <iostream>
#include <algorithm>

int simpleSort(char **av);
