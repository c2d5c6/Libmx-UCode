#include "moveAlong.h"

void vectorString(int ac, char **av) {
    std::vector<std::string> comparator;
    for (int i = 1; i < ac; ++i) {
        comparator.push_back(av[i]);
    }
    for (auto& iterator : comparator) {
        if (IteratorSearch(iterator, "mercer") != std::string::npos ||
            IteratorSearch(iterator, "emer") != std::string::npos ||
            IteratorSearch(iterator, "jim") != std::string::npos)
            std::cout << iterator << ", move along!\n";
    }
}
