#include "bookSave.h"

void ExecutionCommand(std::map<std::string, std::string>& book, std::vector<std::string>& commands) {
    if (commands[0] == "add" && CheckSizeCommand(commands, 2) == 1) {
        AddBook(book, commands[1]);
    }
    else if (commands[0] == "delete" && CheckSizeCommand(commands, 2) == 1) {
        DeleteBook(book, commands[1]);
    }
    else if (commands[0] == "read" && CheckSizeCommand(commands, 2) == 1) {
        ReadBook(book, commands[1]);
    }
    else if (commands[0] == "list" && CheckSizeCommand(commands, 1) == 1) {
        ListBook(book);
    }
    else if (commands[0] == "quit" && CheckSizeCommand(commands, 1) == 1) {
        std::cout << "bye" << std::endl;
        exit(0);
    }
    else {
        InvalidArgument("invalid command");
    }
}