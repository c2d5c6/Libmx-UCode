#pragma once

#include <vector>
#include <iostream>
#include <algorithm>

size_t IteratorSearch(std::string data, std::string toSearch);
void vectorString(int ac, char **av);
