#include "bookSave.h"

void ListBook(std::map<std::string, std::string>& book) {
    for (const auto& b : book) {
        std::cout << b.first << std::endl;
    }
}
