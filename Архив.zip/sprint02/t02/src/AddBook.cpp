#include "bookSave.h"

void InvalidArgument(std::string error) {
    std::cerr << error << std::endl;
}

void AddBook(std::map<std::string, std::string>& books, std::string& book) {
    std::string path = "./Library/" + book;
    std::ifstream fin(path);
    if (fin.is_open()) {
        std::string content(std::istreambuf_iterator<char>(fin), {});
        books[book] = content;
        std::cout << book << " added\n";
    }
    else {
        InvalidArgument("invalid book");
    }
}
