#include "moveAlong.h"

int main(int ac, char *av[]) {
    if (ac == 1) {
        std::cerr << "usage: ./moveAlong [args]\n";
    }
    vectorString(ac, av);
    return (0);
}
