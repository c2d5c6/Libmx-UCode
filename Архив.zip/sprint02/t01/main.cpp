#include "countUniqueWords.h"

int main(int argc, char **argv) {
    if (argc == 2) {
        Words words;
        std::ifstream fd;
        fd.open(argv[1]);
        if (fd.is_open()) {
            try {
                ReadFile(words, fd);
                OutInfo(words, argv[1]);
            }
            catch (...) {
                std::cerr << "error\n";
            }
        }
        else {
            std::cerr << "error\n";
        }
        fd.close();
    }
    else {
        std::cerr << "usage: ./countUniqueWords [file_name]\n";
        return 1;
    }
    return 0;
}