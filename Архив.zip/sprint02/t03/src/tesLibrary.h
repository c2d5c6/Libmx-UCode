#pragma once

#include <string>
#include <map>
#include <fstream>
#include <iostream>
#include <regex>
#include <utility>

bool CheckLineAndAdd(std::multimap<std::string, std::string>& library, std::ifstream& stream);
void PrintLibrary(std::multimap<std::string, std::string> &library, const std::string& author);
