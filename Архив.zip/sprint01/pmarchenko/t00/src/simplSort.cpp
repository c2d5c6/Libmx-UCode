#include "simpleSort.h"

int simpleSort(char **av) {
    std::array<std::string, 5> comparator;
    for (size_t i = 1, j = 0; j < comparator.size(); ++i, ++j) {
        comparator[j] = av[i];
    }
    sort(comparator.begin(), comparator.end());
    for (size_t i = 0; i < comparator.size(); ++i) {
        if (i == comparator.size() - 1) {
            std::cout << comparator[i] << std::endl;
        }
        else {
            std::cout << comparator[i] << " ";
        }
    }
    return 0;
}
