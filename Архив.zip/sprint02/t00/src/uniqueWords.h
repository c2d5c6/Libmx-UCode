#pragma once

#include <iostream>
#include <string>
#include <vector>
#include <set>
#include <fstream>
#include <ostream>
#include <sstream>

void OutInfo(std::set<std::string>& uniqueWords, char* argv);
void ReadFile (std::set<std::string>& uniqueWords, std::ifstream& fin);
void ReadLineAndAdd(std::set<std::string>& uniqueWords, std::string& data);
void DeletePunctuationMarks(std::string& line);
std::string CreateNewNameFile(char *old_name);
