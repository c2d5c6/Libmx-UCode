#include "tesLibrary.h"

void PrintLibrary(std::multimap<std::string, std::string> &library, const std::string& author) {
    int count = 1;
    std::cout << author << ":\n";
    for (const auto& lib : library) {
        if (lib.first == author) {
            std::cout << " " << count++ << ". " << lib.second << std::endl;
        }
    }
}
